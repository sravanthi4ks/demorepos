import os
import pickle
import faiss
import numpy as np

from dotenv import load_dotenv
from openai import OpenAI
from sentence_transformers import SentenceTransformer
from langchain_community.document_loaders import TextLoader

# -------------------------------------------------------
# Load Environment Variables
# -------------------------------------------------------

load_dotenv()

API_KEY = os.getenv("NVIDIA_API_KEY")

if not API_KEY:
    raise ValueError("NVIDIA_API_KEY not found in .env")

# -------------------------------------------------------
# NVIDIA Client
# -------------------------------------------------------

client = OpenAI(
    base_url="https://integrate.api.nvidia.com/v1",
    #api_key=API_KEY,
    api_key="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"
)

# -------------------------------------------------------
# Load Embedding Model
# -------------------------------------------------------

print("Loading embedding model...")

embedding_model = SentenceTransformer("all-MiniLM-L6-v2")

print("Embedding model loaded.")

# -------------------------------------------------------
# Create FAISS Folder
# -------------------------------------------------------

INDEX_DIR = "faiss_index"

os.makedirs(INDEX_DIR, exist_ok=True)

INDEX_FILE = os.path.join(INDEX_DIR, "index.faiss")
DOC_FILE = os.path.join(INDEX_DIR, "documents.pkl")

# -------------------------------------------------------
# Build Index (Only First Time)
# -------------------------------------------------------

if not os.path.exists(INDEX_FILE):

    print("Building FAISS index...")

    documents = []

    docs_folder = "docs"

    for file in os.listdir(docs_folder):

        if file.endswith(".txt"):

            loader = TextLoader(
                os.path.join(docs_folder, file),
                encoding="utf-8"
            )

            documents.extend(loader.load())

    texts = []

    for doc in documents:

        paragraphs = doc.page_content.split("\n\n")

        for p in paragraphs:

            p = p.strip()

            if len(p) > 0:
                texts.append(p)

    embeddings = embedding_model.encode(
        texts,
        convert_to_numpy=True
    ).astype("float32")

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatL2(dimension)

    index.add(embeddings)

    faiss.write_index(index, INDEX_FILE)

    with open(DOC_FILE, "wb") as f:
        pickle.dump(texts, f)

    print("FAISS index created.")

# -------------------------------------------------------
# Load Existing Index
# -------------------------------------------------------

index = faiss.read_index(INDEX_FILE)

with open(DOC_FILE, "rb") as f:
    texts = pickle.load(f)

print("Vector database loaded.")

# -------------------------------------------------------
# Retrieval Function
# -------------------------------------------------------

def retrieve(query, k=2):

    query_vector = embedding_model.encode(
        [query],
        convert_to_numpy=True
    ).astype("float32")

    distances, indices = index.search(query_vector, k)

    results = []

    for idx in indices[0]:

        results.append(texts[idx])

    return "\n\n".join(results)

# -------------------------------------------------------
# Chat Loop
# -------------------------------------------------------

print("\n==============================")
print(" Simple NVIDIA RAG Agent")
print("==============================")

while True:

    question = input("\nYou : ")

    if question.lower() == "exit":
        break

    context = retrieve(question)

    prompt = f"""
You are an AI assistant.

Answer ONLY using the provided context.

If the answer is not available, reply:

I don't know based on the provided documents.

Context:

{context}

Question:

{question}
"""

    response = client.chat.completions.create(
        model="meta/llama-3.1-8b-instruct",
        messages=[
            {
                "role": "system",
                "content": "Answer only from the supplied context."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0
    )

    print("\nAI:\n")

    print(response.choices[0].message.content)