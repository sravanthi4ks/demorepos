from planner import create_travel_plan
from hotels import recommend_hotels
from packing import create_packing_list



print("="*50)
print("AI Vacation Planner")
print("="*50)

destination = input("Destination: ")
days = input("Days: ")
budget = input("Budget (USD): ")
style = input("Travel Style (Luxury/Budget/Adventure): ")
travelers = input("Number of Travelers: ")
weather = input("Expected Weather (e.g., 25°C, Sunny): ")
print("\nGenerating plan...\n")
#hotels = recommend_hotels(destination, budget, travelers, style)
plan = create_travel_plan(
    destination,
    days,
    budget,
    style,
    travelers
)

packing = create_packing_list(
    destination,
    days,
    style,
    weather
)


print("\n========================================\n")
#print("\nRecommended Hotels:\n")
print("\n========================================\n")
#print(hotels)
print("\n========================================\n")
print("\nTravel Plan:\n")
print("\n========================================\n")
print(plan)

print("\n========================================\n")
print("\nPacking List:\n")
print("\n========================================\n")
print(packing)