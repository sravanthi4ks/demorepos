# import os
# from dotenv import load_dotenv
# from openai import OpenAI

# load_dotenv()

# client = OpenAI(
#     base_url="https://integrate.api.nvidia.com/v1",
#     api_key=os.getenv("NVIDIA_API_KEY"),
# )

# MODEL = "meta/llama-3.1-8b-instruct"
# # Or:
# # MODEL = "moonshotai/kimi-k2.6"


import os
from dotenv import load_dotenv
from openai import OpenAI, api_key

load_dotenv()

API_KEY = os.getenv("NVIDIA_API_KEY")

#print("API Key Loaded:", API_KEY[:15] + "..." if API_KEY else "NOT FOUND")

if not API_KEY:
    raise ValueError("NVIDIA_API_KEY not found in .env")

client = OpenAI(
    base_url="https://integrate.api.nvidia.com/v1",
    api_key=API_KEY,
)

MODEL = "meta/llama-3.1-8b-instruct"
# MODEL = "moonshotai/kimi-k2.6"