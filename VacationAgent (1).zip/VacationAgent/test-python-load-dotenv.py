import os
from dotenv import find_dotenv, load_dotenv
from openai import OpenAI

env_path = find_dotenv()

print("Loading:", env_path)

load_dotenv(env_path)