from utils import client, MODEL


def recommend_hotels(destination, budget_limit, travelers, travel_style):
    """
    Recommend hotels based on destination, budget, travelers, and travel style.
    """

    prompt = f"""
You are an expert travel consultant.

Recommend hotels for the following trip.

Destination: {destination}
Budget: {budget_limit}
Number of Travelers: {travelers}
Travel Style: {travel_style}

Recommend 5 hotels.

For each hotel provide:

Hotel Name:
Star Rating:
Approximate Price per Night:
Location:
Why it is Recommended:
Best For:

Finally recommend the BEST hotel among the five and explain why.

Format the response neatly.
"""

    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.3,
        messages=[
            {
                "role": "system",
                "content": "You are an expert hotel recommendation assistant."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content


# --------------------------
# Test the module directly
# --------------------------
if __name__ == "__main__":

    hotels = recommend_hotels(
        destination="Tokyo, Japan",
        budget_limit="$3000",
        travelers=2,
        travel_style="Budget"
    )

    print(hotels)