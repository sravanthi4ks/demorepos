from utils import client, MODEL


def create_itinerary(destination, days, travel_style, travelers):
    """
    Generate a day-by-day travel itinerary.
    """

    prompt = f"""
You are an expert travel planner.

Create a detailed travel itinerary.

Destination: {destination}
Number of Days: {days}
Travel Style: {travel_style}
Number of Travelers: {travelers}

For EACH day include:

Day Number

Morning:
- Activities

Afternoon:
- Activities

Evening:
- Activities

Recommended Food:
Transportation:
Estimated Daily Cost:
Travel Tips:

After the itinerary, include:

Top Attractions Not to Miss

Local Foods to Try

Useful Travel Tips

Emergency Contact Advice

Format the response neatly using headings and bullet points.
"""

    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.4,
        messages=[
            {
                "role": "system",
                "content": "You are an experienced international travel planner."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content


# ----------------------------------------------------
# Test the module directly
# ----------------------------------------------------
if __name__ == "__main__":

    itinerary = create_itinerary(
        destination="Tokyo, Japan",
        days=5,
        travel_style="Budget",
        travelers=2
    )

    print(itinerary)