from utils import client, MODEL


def create_packing_list(destination, days, travel_style, weather=25):
    """
    Generate a packing checklist based on destination, duration,
    travel style, and expected weather.
    """

    prompt = f"""
You are an expert travel packing assistant.

Generate a complete packing checklist.

Destination: {destination}
Trip Duration: {days} days
Travel Style: {travel_style}
Expected Weather: {weather}

Organize the checklist into the following categories:

1. Travel Documents
2. Clothing
3. Footwear
4. Toiletries
5. Electronics
6. Medicines & First Aid
7. Travel Accessories
8. Money & Payment
9. Optional Items

For each category provide a checklist using ✓.

At the end include:

Travel Tips:
Things to Avoid Packing:
"""

    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.3,
        messages=[
            {
                "role": "system",
                "content": "You are an experienced travel packing expert."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content


# ------------------------------------
# Test this module directly
# ------------------------------------
if __name__ == "__main__":

    packing = create_packing_list(
        destination="Tokyo, Japan",
        days=5,
        travel_style="Budget",
        weather="15°C–22°C, Mild with occasional rain"
    )

    print(packing)