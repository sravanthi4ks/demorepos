import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

#print("API Key Loaded:", os.getenv("NVIDIA_API_KEY")[:15] + "..." if os.getenv("NVIDIA_API_KEY") else "NOT FOUND")
print("API Key Loaded:", os.getenv("NVIDIA_API_KEY") + "..." if os.getenv("NVIDIA_API_KEY") else "NOT FOUND")

client = OpenAI(
    base_url="https://integrate.api.nvidia.com/v1",
    #api_key=os.getenv("NVIDIA_API_KEY")
    api_key="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"
)

response = client.chat.completions.create(
    model="meta/llama-3.1-8b-instruct",
    messages=[
        {"role": "user", "content": "Say hello."}
    ],
)

print(response.choices[0].message.content)