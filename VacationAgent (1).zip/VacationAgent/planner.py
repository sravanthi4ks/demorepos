from utils import client, MODEL


#========================================================== 


from budget import estimate_budget
from hotels import recommend_hotels
from itinerary import create_itinerary
from packing import create_packing_list


def create_travel_plan(destination, days, budget, style, travelers):

    print("\nEstimating budget...")
    budget_result = estimate_budget(
        destination,
        days,
        budget,
        travelers
    )

    print("Finding hotels...")
    hotels_result = recommend_hotels(
        destination,
        budget,
        travelers,
        style
    )

    print("Creating itinerary...")
    itinerary_result = create_itinerary(
        destination,
        days,
        style,
        travelers
    )

    weather = "Moderate weather"

    print("Creating packing checklist...")
    packing_result = create_packing_list(
        destination,
        days,
        style,
        weather
    )

    final_plan = f"""
==========================================
        AI VACATION TRAVEL PLAN
==========================================

Destination:
{destination}

Days:
{days}

Travel Style:
{style}

Number of Travelers:
{travelers}

Budget:
{budget}

------------------------------------------
BUDGET ESTIMATE
------------------------------------------
{budget_result}

------------------------------------------
HOTEL RECOMMENDATIONS
------------------------------------------
{hotels_result}

------------------------------------------
DAY-BY-DAY ITINERARY
------------------------------------------
{itinerary_result}

------------------------------------------
PACKING CHECKLIST
------------------------------------------
{packing_result}
"""

    return final_plan





#========================================================== 

# def create_travel_plan(destination, days, budget, style, travelers):

#     prompt = f"""
# You are an expert travel planner.

# Destination:
# {destination}

# Days:
# {days}

# Budget:
# {budget}

# Travel Style:
# {style}

# Travelers:
# {travelers}

# Generate:

# 1. Best travel dates
# 2. Budget estimate
# 3. Hotel recommendations
# 4. Day-by-day itinerary
# 5. Packing checklist

# Format nicely.
# """

#     response = client.chat.completions.create(
#         model=MODEL,
#         messages=[
#             {
#                 "role":"user",
#                 "content":prompt
#             }
#         ],
#         temperature=0.5
#     )

#     return response.choices[0].message.content