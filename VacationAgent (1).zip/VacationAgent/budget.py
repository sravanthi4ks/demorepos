from utils import client, MODEL


def estimate_budget(destination, days, budget_limit, travelers):
    """
    Estimate the travel budget.
    """

    prompt = f"""
You are an expert travel budget planner.

Create a realistic budget estimate for the following trip.

Destination: {destination}
Number of Days: {days}
Number of Travelers: {travelers}
Maximum Budget: {budget_limit}

Provide the response in the following format:

Estimated Budget

Flights:
Hotels:
Food:
Transportation:
Activities:
Shopping:
Miscellaneous:

Total Estimated Cost:

Also mention whether the trip is:
- Under Budget
- Within Budget
- Over Budget

Finally, give 3 money-saving tips.
"""

    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.2,
        messages=[
            {
                "role": "system",
                "content": "You are a professional travel budget planner."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content